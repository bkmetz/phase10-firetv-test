# Phase 10 Game Night - Midnight Neon prototype

Early development build, not a finished production multiplayer game.

## What works in the prototype
- New Midnight Neon / Electric Lime UI, responsive up to 10 player cards.
- TV lobby, room code, QR join URL (third-party QR image endpoint requires internet).
- Anonymous Firebase sign-in, first phone player becomes host, player join, basic score submission and host total-score correction.
- 10-player visual demo available on web home screen.

## Known blockers before production use
- Firestore security rules from the old game are incompatible with room creation where `hostUid` starts null and must NOT be deployed unchanged. Rules must securely enforce first-host assignment, 10-player cap, authorized host actions and score integrity. Client-side player count checks are not authoritative and can race.
- The TV WebView loads a file:// origin. Firebase Auth's web domain/origin requirements and remote Firebase modules may prevent real multiplayer from working in this APK. The preferred production approach is to host the new app on an authorized HTTPS domain and point the TV WebView at that URL.
- Score corrections have no audit trail; previous round button is intentionally disabled; no persisted game history, guest profiles, Google login, stats or achievements.
- `next round` currently does not ensure all scores are submitted. Phase 10 win/finish logic is incomplete.
- Firebase configuration references the existing project; test in a separate Firebase project or staging database before deploying any rules or live site changes.
- No APK has been compiled or tested as part of this package.

## Build
Upload the extracted repository contents to a GitHub repository, run Actions > Build Midnight Neon Fire TV APK > Run workflow, and download the artifact. This is a source-only prototype, not a verified installation build.
