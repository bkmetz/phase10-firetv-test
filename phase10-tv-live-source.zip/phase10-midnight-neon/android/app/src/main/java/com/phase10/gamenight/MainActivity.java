package com.phase10.gamenight;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
 private WebView web;
 private static final String GAME_URL = "https://coruscating-tarsier-e26033.netlify.app/";
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().getDecorView().setSystemUiVisibility(5894);
  web = new WebView(this);
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setDatabaseEnabled(true);
  settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
  settings.setMediaPlaybackRequiresUserGesture(false);
  web.setBackgroundColor(Color.rgb(12,14,31));
  web.setWebChromeClient(new WebChromeClient());
  web.setWebViewClient(new WebViewClient() {
   @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
    if (request.isForMainFrame()) view.loadDataWithBaseURL(null,
      "<html><body style='background:#0c0e1f;color:white;font-family:sans-serif;text-align:center;padding:15vh 4vw'><h1>Phase 10 Game Night</h1><p>Unable to load the game. Check the TV internet connection.</p><p>Press Back to retry.</p></body></html>",
      "text/html", "UTF-8", null);
   }
  });
  web.setFocusable(true);
  web.setFocusableInTouchMode(true);
  setContentView(web);
  web.loadUrl(GAME_URL);
  web.requestFocus();
 }
 @Override public void onBackPressed() {
  if (web != null && web.getUrl() != null && web.getUrl().startsWith("data:")) web.loadUrl(GAME_URL);
  else if (web != null && web.canGoBack()) web.goBack();
  else if (web != null) web.loadUrl(GAME_URL);
 }
 @Override protected void onDestroy() { if(web != null) web.destroy(); super.onDestroy(); }
}
