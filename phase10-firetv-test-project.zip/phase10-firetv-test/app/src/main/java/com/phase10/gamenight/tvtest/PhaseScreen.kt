package com.phase10.gamenight.tvtest

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.KeyEvent
import android.view.View
import kotlin.math.min

class PhaseScreen(context: Context) : View(context) {
    private val navy = Color.rgb(7, 17, 38)
    private val panel = Color.rgb(16, 34, 64)
    private val lime = Color.rgb(174, 255, 55)
    private val cyan = Color.rgb(48, 220, 245)
    private val white = Color.rgb(245, 249, 255)
    private val muted = Color.rgb(160, 180, 207)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var selected = 0
    var isConfirmation = false
        private set

    init { isFocusable = true; isFocusableInTouchMode = true; requestFocus() }

    fun showHome() {
        isConfirmation = false
        selected = 0
        invalidate()
    }

    fun handleRemoteKey(keyCode: Int): Boolean {
        if (isConfirmation) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                // Confirmation screen has a single, clearly selectable return action.
                showHome()
                return true
            }
            return false
        }
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_UP -> selected = (selected + 1) % 2
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_DOWN -> selected = (selected + 1) % 2
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (selected == 0) isConfirmation = true else (context as? android.app.Activity)?.finish()
            }
            else -> return false
        }
        invalidate()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val sx = width / 1920f
        val sy = height / 1080f
        val scale = min(sx, sy)
        canvas.save()
        canvas.scale(scale, scale)
        val ox = (width - 1920f * scale) / 2f
        val oy = (height - 1080f * scale) / 2f
        canvas.translate(ox / scale, oy / scale)
        canvas.drawColor(navy)
        // Quiet geometric texture and accent rails.
        p.color = Color.rgb(11, 27, 54); p.style = Paint.Style.FILL
        canvas.drawCircle(1650f, 180f, 360f, p)
        canvas.drawCircle(180f, 1000f, 300f, p)
        p.color = lime
        canvas.drawRoundRect(RectF(100f, 95f, 112f, 985f), 6f, 6f, p)
        p.color = cyan
        canvas.drawRoundRect(RectF(1720f, 120f, 1726f, 960f), 3f, 3f, p)

        if (isConfirmation) drawConfirmation(canvas) else drawHome(canvas)
        canvas.restore()
    }

    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float,
                     color: Int, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) {
        p.color = color; p.textSize = size; p.typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        p.textAlign = align; p.style = Paint.Style.FILL
        canvasText(c, value, x, y)
    }
    private fun canvasText(c: Canvas, value: String, x: Float, y: Float) { c.drawText(value, x, y, p) }

    private fun drawHome(c: Canvas) {
        text(c, "GAME NIGHT", 180f, 205f, 38f, cyan, true)
        text(c, "PHASE", 170f, 405f, 150f, white, true)
        text(c, "10", 690f, 405f, 190f, lime, true)
        text(c, "FIRE TV COMPATIBILITY TEST", 180f, 500f, 42f, muted, true)
        text(c, "A native television app. Built for the big screen.", 180f, 565f, 28f, white)
        drawQr(c, 1320f, 255f, 260f)
        text(c, "DECORATIVE QR AREA", 1450f, 565f, 22f, cyan, true, Paint.Align.CENTER)
        text(c, "Use your Fire TV remote to begin", 180f, 690f, 28f, muted)
        drawButton(c, RectF(180f, 755f, 600f, 865f), "START TEST", selected == 0, lime)
        drawButton(c, RectF(635f, 755f, 930f, 865f), "EXIT", selected == 1, cyan)
        text(c, "SELECT: choose     BACK: return", 180f, 950f, 22f, muted)
        text(c, "NATIVE FIRE TV BUILD  •  TEST 1.0", 1700f, 1000f, 18f, muted, false, Paint.Align.RIGHT)
    }

    private fun drawConfirmation(c: Canvas) {
        text(c, "PHASE 10", 960f, 290f, 92f, lime, true, Paint.Align.CENTER)
        text(c, "REMOTE CONTROL CONFIRMED", 960f, 420f, 48f, cyan, true, Paint.Align.CENTER)
        text(c, "Your Fire TV successfully sent the Select command.", 960f, 505f, 30f, white, false, Paint.Align.CENTER)
        text(c, "The native app is running in full-screen landscape mode.", 960f, 565f, 26f, muted, false, Paint.Align.CENTER)
        drawButton(c, RectF(650f, 700f, 1270f, 820f), "BACK TO TEST SCREEN", true, lime)
        text(c, "Press BACK on your remote to return.", 960f, 910f, 24f, muted, false, Paint.Align.CENTER)
    }

    private fun drawButton(c: Canvas, r: RectF, label: String, focused: Boolean, accent: Int) {
        p.style = Paint.Style.FILL
        p.color = if (focused) Color.rgb(29, 54, 82) else panel
        c.drawRoundRect(r, 22f, 22f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = if (focused) 7f else 3f
        p.color = if (focused) accent else Color.rgb(65, 91, 125)
        c.drawRoundRect(r, 22f, 22f, p)
        p.style = Paint.Style.FILL
        text(c, label, r.centerX(), r.centerY() + 13f, 30f, if (focused) accent else white, true, Paint.Align.CENTER)
    }

    private fun drawQr(c: Canvas, x: Float, y: Float, size: Float) {
        p.color = white; p.style = Paint.Style.FILL
        c.drawRoundRect(RectF(x - 18, y - 18, x + size + 18, y + size + 18), 16f, 16f, p)
        val cells = 25
        val cell = size / cells
        p.color = navy
        for (row in 0 until cells) for (col in 0 until cells) {
            val finder = inFinder(row, col)
            val on = if (finder != null) finder else ((row * 17 + col * 29 + row * col * 3) % 7 < 3)
            if (on) c.drawRect(x + col * cell, y + row * cell, x + (col + 1) * cell - 2, y + (row + 1) * cell - 2, p)
        }
        p.color = lime
        c.drawRoundRect(RectF(x + size - 52, y + size - 52, x + size - 8, y + size - 8), 6f, 6f, p)
    }

    private fun inFinder(r: Int, col: Int): Boolean? {
        val starts = listOf(0 to 0, 0 to 18, 18 to 0)
        for ((sr, sc) in starts) {
            val rr = r - sr; val cc = col - sc
            if (rr in 0..6 && cc in 0..6) return rr == 0 || rr == 6 || cc == 0 || cc == 6 || (rr in 2..4 && cc in 2..4)
        }
        return null
    }
}
