# Phase 10 Game Night - Fire TV Compatibility Test

This is a separate native Android application project. It does not replace or modify the existing web app or Firebase project.

## Device target
- Amazon Fire OS 7 / Android 9 generation
- Minimum SDK: 28 (Android 9)
- Target SDK: 28 for the initial compatibility test
- Compile SDK: 35
- Kotlin + native Android View
- Landscape, immersive full-screen
- Leanback launcher entry and touchscreen-not-required declaration
- DPAD/Select remote navigation

The QR pattern is decorative and is not a scannable join code.

## Build
GitHub Actions compiles the project in the cloud. Expected output:
`app/build/outputs/apk/debug/app-debug.apk`

This ZIP is source code, not an APK. Do not rename it to `.apk`.

## iPhone + GitHub setup
1. In GitHub, create a new **public** repository named `phase10-firetv-test`. A public repository makes the eventual release download easiest.
2. Upload `phase10-firetv-test-project.zip` to the repository root. Do not extract or rename it.
3. In the repository, choose **Add file > Create new file**.
4. Name the new file exactly `.github/workflows/build-apk.yml`.
5. Paste the workflow contents from the separate `github-workflow-build-apk.yml` file included in this ZIP, or use the workflow text supplied in the project instructions.
6. Commit the new file.
7. Open **Actions**. Select **Build Fire TV test APK** and choose **Run workflow**.
8. When the run completes successfully, download the `phase10-firetv-test-apk` artifact. It will be a ZIP containing `app-debug.apk`.

## Downloader release
Workflow artifacts are temporary and require GitHub access, so they are not the final Downloader link. After a successful build, create a GitHub Release and attach the extracted `app-debug.apk` file. The release asset URL is the one to enter in Downloader.

## Important
This is a debug-signed compatibility APK. It is appropriate for this private installation test, not a production release. The QR graphic is decorative. No Firebase connection or permissions are used.
